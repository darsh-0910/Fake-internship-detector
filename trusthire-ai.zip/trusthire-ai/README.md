# TrustHire AI

Detect the fake. Discover the real.

- `backend/`: FastAPI service (rules, extraction, URL checks, baseline ML, opportunities API)
- `frontend/`: React + Tailwind dashboard

Start the backend on port 8000, then the frontend on port 5173. See each folder's README.
