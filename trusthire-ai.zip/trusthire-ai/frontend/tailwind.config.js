/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        chalk: "#F6F7F3",
        pine: { 900: "#10322A", 700: "#1D5444", 100: "#DCE9E3" },
        signal: "#E0A100",
        alarm: "#B83227",
        steady: "#1F7A5C",
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', "system-ui", "sans-serif"],
        body: ['"Source Sans 3"', "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
