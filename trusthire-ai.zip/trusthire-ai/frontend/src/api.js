const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function request(path, options) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, options);
  } catch {
    throw new Error("Cannot reach the server. Check that the backend is running on " + BASE);
  }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail; } catch { /* ignore */ }
    const msg = Array.isArray(detail) ? detail.map((d) => d.msg).join(", ") : detail;
    throw new Error(msg || `Request failed (${res.status})`);
  }
  return res.json();
}

export const analyzeMessage = (payload) =>
  request("/api/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

export const searchOpportunities = (params) => {
  const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v)).toString();
  return request(`/api/opportunities${qs ? "?" + qs : ""}`);
};
