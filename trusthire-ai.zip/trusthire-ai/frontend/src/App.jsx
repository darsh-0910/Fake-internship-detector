import { useState } from "react";
import Analyzer from "./components/Analyzer.jsx";
import Opportunities from "./components/Opportunities.jsx";

export default function App() {
  const [tab, setTab] = useState("check");
  const tabClass = (t) =>
    `px-4 py-2 font-semibold border-b-4 ${tab === t ? "border-signal" : "border-transparent hover:border-pine-100"}`;

  return (
    <div className="mx-auto max-w-4xl px-4 pb-16">
      <header className="pt-10">
        <h1 className="text-5xl font-bold tracking-tight">TrustHire AI</h1>
        <p className="mt-1 text-lg">Detect the fake. Discover the real.</p>
        <nav className="mt-6 flex gap-2 border-b border-pine-100" aria-label="Sections">
          <button className={tabClass("check")} onClick={() => setTab("check")} aria-current={tab === "check"}>Check a message</button>
          <button className={tabClass("find")} onClick={() => setTab("find")} aria-current={tab === "find"}>Find opportunities</button>
        </nav>
      </header>
      <main className="mt-8">{tab === "check" ? <Analyzer /> : <Opportunities />}</main>
      <footer className="mt-16 border-t border-pine-100 pt-4 text-sm">
        Risk scores are estimates and can be wrong. Never pay a recruitment fee or share OTPs, passwords or bank details.
      </footer>
    </div>
  );
}
