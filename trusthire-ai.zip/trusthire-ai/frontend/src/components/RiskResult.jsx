const LEVEL = {
  lower: { bar: "bg-steady", text: "text-steady", ring: "border-steady" },
  caution: { bar: "bg-signal", text: "text-[#8A6400]", ring: "border-signal" },
  high: { bar: "bg-alarm", text: "text-alarm", ring: "border-alarm" },
};
const SEVERITY = {
  high: "border-l-alarm",
  medium: "border-l-signal",
  low: "border-l-pine-700",
  positive: "border-l-steady",
};

export default function RiskResult({ result }) {
  const c = LEVEL[result.level];
  return (
    <section aria-live="polite" className={`mt-8 rounded-lg border-2 ${c.ring} bg-white p-6`}>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className={`text-3xl font-bold ${c.text}`}>{result.label}</h2>
          <p className="mt-2 max-w-prose">{result.summary}</p>
        </div>
        <div className="text-right">
          <div className="font-display text-5xl font-bold">{result.score}<span className="text-xl">/100</span></div>
        </div>
      </div>

      <div className="mt-4 h-3 w-full overflow-hidden rounded-full bg-pine-100" role="img" aria-label={`Risk score ${result.score} out of 100`}>
        <div className={`h-full ${c.bar} transition-all duration-500`} style={{ width: `${result.score}%` }} />
      </div>

      <h3 className="mt-8 text-xl font-bold">Why we scored it this way</h3>
      {result.signals.length === 0 ? (
        <p className="mt-2">No specific warning signs were found in the text.</p>
      ) : (
        <ul className="mt-3 space-y-3">
          {result.signals.map((s, i) => (
            <li key={s.id + i} className={`border-l-4 ${SEVERITY[s.severity]} bg-chalk py-2 pl-4 pr-3`}>
              <p className="font-semibold">{s.title}</p>
              <p className="text-sm">{s.detail}</p>
            </li>
          ))}
        </ul>
      )}

      {result.link_checks.length > 0 && (
        <>
          <h3 className="mt-8 text-xl font-bold">Links found (not opened)</h3>
          <ul className="mt-3 space-y-2 text-sm">
            {result.link_checks.map((l) => (
              <li key={l.url} className="rounded bg-chalk p-3">
                <p className="break-all font-semibold">{l.url}</p>
                <p>{l.flags.length ? l.flags.join("; ") + "." : l.note}</p>
              </li>
            ))}
          </ul>
        </>
      )}

      <Entities e={result.entities} />

      <h3 className="mt-8 text-xl font-bold">What to do next</h3>
      <ul className="mt-3 list-disc space-y-1 pl-5">
        {result.next_steps.map((s) => <li key={s}>{s}</li>)}
      </ul>

      <p className="mt-8 border-t border-pine-100 pt-4 text-sm">{result.disclaimer}</p>
    </section>
  );
}

function Entities({ e }) {
  const rows = [
    ["Company", e.company],
    ["Role", e.role],
    ["Emails", e.emails.join(", ")],
    ["Phones", e.phones.join(", ")],
    ["Amounts", e.amounts.join(", ")],
  ].filter(([, v]) => v);
  if (!rows.length) return null;
  return (
    <>
      <h3 className="mt-8 text-xl font-bold">Details we found</h3>
      <dl className="mt-3 grid grid-cols-[8rem_1fr] gap-y-1 text-sm">
        {rows.map(([k, v]) => (
          <div key={k} className="contents">
            <dt className="font-semibold">{k}</dt>
            <dd className="break-all">{v}</dd>
          </div>
        ))}
      </dl>
    </>
  );
}
