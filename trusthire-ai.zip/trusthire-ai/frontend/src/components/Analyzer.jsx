import { useState } from "react";
import { analyzeMessage } from "../api.js";
import RiskResult from "./RiskResult.jsx";

const EXAMPLE =
  "Congratulations! You are selected for a work from home internship at Nova Technologies Pvt Ltd. " +
  "Pay Rs 999 registration fee today to confirm your seat. Contact us on WhatsApp. Register: http://bit.ly/nova-join";

export default function Analyzer() {
  const [message, setMessage] = useState("");
  const [sender, setSender] = useState("");
  const [company, setCompany] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      setResult(
        await analyzeMessage({
          message,
          sender_email: sender || null,
          claimed_company: company || null,
        })
      );
    } catch (err) {
      setResult(null);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h2 className="text-3xl font-bold">Check a message</h2>
      <p className="mt-2 max-w-prose">
        Paste an internship or job message from WhatsApp, SMS, Telegram or email. We never open the links in it.
      </p>

      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <div>
          <label htmlFor="msg" className="font-semibold">Message</label>
          <textarea
            id="msg" required minLength={5} maxLength={8000} rows={7}
            value={message} onChange={(e) => setMessage(e.target.value)}
            className="mt-1 w-full rounded-md border border-pine-700/40 bg-white p-3"
            placeholder="Paste the message here"
          />
          <button type="button" onClick={() => setMessage(EXAMPLE)} className="mt-1 text-sm underline">
            Use an example scam message
          </button>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="sender" className="font-semibold">Recruiter email (optional)</label>
            <input id="sender" type="text" value={sender} onChange={(e) => setSender(e.target.value)}
              className="mt-1 w-full rounded-md border border-pine-700/40 bg-white p-2" />
          </div>
          <div>
            <label htmlFor="company" className="font-semibold">Company they claim (optional)</label>
            <input id="company" type="text" value={company} onChange={(e) => setCompany(e.target.value)}
              className="mt-1 w-full rounded-md border border-pine-700/40 bg-white p-2" />
          </div>
        </div>
        <p className="text-sm">Do not enter passwords, OTPs or bank details here. We never need them.</p>
        <button type="submit" disabled={loading}
          className="rounded-md bg-pine-900 px-5 py-2.5 font-semibold text-chalk hover:bg-pine-700 disabled:opacity-60">
          {loading ? "Checking..." : "Check this message"}
        </button>
      </form>

      {error && <p role="alert" className="mt-4 rounded bg-alarm/10 p-3 text-alarm">{error}</p>}
      {result && <RiskResult result={result} />}
    </div>
  );
}
