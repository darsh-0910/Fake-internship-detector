import { useEffect, useState } from "react";
import { searchOpportunities } from "../api.js";

const STATUS_STYLE = {
  verified: "bg-steady/15 text-steady",
  "source checked": "bg-signal/20 text-[#7A5800]",
  "not yet verified": "bg-pine-100 text-pine-900",
};

export default function Opportunities() {
  const [filters, setFilters] = useState({ skills: "", location: "", mode: "", type: "" });
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load(f = filters) {
    setLoading(true);
    setError("");
    try {
      setItems(await searchOpportunities(f));
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const set = (k) => (e) => setFilters({ ...filters, [k]: e.target.value });

  return (
    <div>
      <h2 className="text-3xl font-bold">Find opportunities</h2>
      <p className="mt-2 max-w-prose">
        Every listing shows where it came from and when it was last checked. Apply through the official source, not through a message.
      </p>
      <form
        onSubmit={(e) => { e.preventDefault(); load(); }}
        className="mt-6 grid gap-3 sm:grid-cols-5"
      >
        <input aria-label="Skills" placeholder="Skills, e.g. python react" value={filters.skills} onChange={set("skills")}
          className="rounded-md border border-pine-700/40 bg-white p-2 sm:col-span-2" />
        <input aria-label="Location" placeholder="Location" value={filters.location} onChange={set("location")}
          className="rounded-md border border-pine-700/40 bg-white p-2" />
        <select aria-label="Work mode" value={filters.mode} onChange={set("mode")}
          className="rounded-md border border-pine-700/40 bg-white p-2">
          <option value="">Any mode</option>
          <option value="remote">Remote</option>
          <option value="hybrid">Hybrid</option>
          <option value="onsite">On-site</option>
        </select>
        <select aria-label="Type" value={filters.type} onChange={set("type")}
          className="rounded-md border border-pine-700/40 bg-white p-2">
          <option value="">Internships and jobs</option>
          <option value="internship">Internships</option>
          <option value="job">Jobs</option>
        </select>
        <button type="submit" className="rounded-md bg-pine-900 px-4 py-2 font-semibold text-chalk hover:bg-pine-700 sm:col-span-5 sm:w-fit">
          Search listings
        </button>
      </form>

      {error && <p role="alert" className="mt-4 rounded bg-alarm/10 p-3 text-alarm">{error}</p>}
      {loading && <p className="mt-6">Loading listings...</p>}
      {!loading && !error && items.length === 0 && (
        <p className="mt-6">No listings match. Try fewer filters or a different skill.</p>
      )}

      <ul className="mt-6 space-y-4">
        {items.map((o) => (
          <li key={o.id} className="rounded-lg border border-pine-700/20 bg-white p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <h3 className="text-xl font-bold">{o.title}</h3>
                <p>{o.company} · {o.location} · {o.mode}</p>
              </div>
              <span className={`rounded px-2 py-1 text-sm font-semibold ${STATUS_STYLE[o.status]}`}>{o.status}</span>
            </div>
            <p className="mt-2 text-sm">Skills: {o.skills.join(", ")}{o.stipend ? ` · Stipend: ${o.stipend}` : ""}</p>
            <p className="mt-1 text-sm">Source: {o.source} · Last checked {o.last_checked}</p>
            <a href={o.apply_url} target="_blank" rel="noopener noreferrer" className="mt-3 inline-block font-semibold underline">
              Open the original listing
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
