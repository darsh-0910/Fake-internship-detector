# TrustHire AI: Frontend (React + Tailwind + Vite)

## Run
```bash
cd frontend
npm install
cp .env.example .env      # set VITE_API_URL if the backend is not on localhost:8000
npm run dev
```
Open http://localhost:5173 (start the backend first, see `../backend/README.md`).

## Structure
- `src/App.jsx`: layout and tabs
- `src/components/Analyzer.jsx`: message form
- `src/components/RiskResult.jsx`: score, reasons, link checks, next steps
- `src/components/Opportunities.jsx`: filterable listings with source and last-checked date
- `src/api.js`: API calls
