from typing import Dict, List, Optional

DISCLAIMER = (
    "This is an automated estimate from the evidence available, not proof that an offer is genuine or "
    "fraudulent. It can be wrong. Verify through the company's official website before you act."
)


def level_for(score: int) -> Dict[str, str]:
    if score <= 30:
        return {"level": "lower", "label": "Lower detected risk"}
    if score <= 60:
        return {"level": "caution", "label": "Needs caution"}
    return {"level": "high", "label": "High detected risk"}


def combine(signals: List[Dict], link_flag_count: int, ml_prob: Optional[float]) -> int:
    """Blend rule weights, link flags and the ML probability into a 0-100 score.

    Rules dominate because they are explainable and precise for clear indicators.
    The ML model nudges borderline messages and can never make a high-risk rule hit look safe.
    """
    rule_score = sum(s["weight"] for s in signals)
    rule_score += min(link_flag_count, 4) * 6

    ml_component = 0.0
    if ml_prob is not None:
        ml_component = ml_prob * 35  # up to 35 points

    score = rule_score + ml_component
    # An explicit high-severity rule hit sets a floor so the model cannot dilute it.
    if any(s["severity"] == "high" for s in signals):
        score = max(score, 55)
    return int(max(0, min(100, round(score))))


def next_steps(level: str, signals: List[Dict]) -> List[str]:
    ids = {s["id"] for s in signals}
    steps: List[str] = []
    if "upfront_fee" in ids:
        steps.append("Do not pay any fee. Genuine employers do not charge for selection, training or documents.")
    if "sensitive_info" in ids:
        steps.append("Do not share OTPs, passwords, bank details or ID documents with this sender.")
    if level in ("high", "caution"):
        steps.append("Find the company's official website yourself (do not use links from the message) and check its careers page for this role.")
        steps.append("Contact the company through the phone number or email listed on its official site to confirm the recruiter.")
    else:
        steps.append("Still confirm the role on the company's official careers page before sharing personal documents.")
    if level == "high":
        steps.append("Stop replying. Report the message on the platform it came from and at cybercrime.gov.in if you lost money.")
        steps.append("Tell your college placement cell so other students are warned.")
    steps.append("Never open suspicious links on a device that holds banking apps or personal data.")
    return steps


def summary_for(level: str, n_signals: int) -> str:
    if level == "high":
        return f"Several strong warning signs were found ({n_signals}). Treat this offer as suspicious until you verify it independently."
    if level == "caution":
        return "Some warning signs were found. This may still be genuine, but verify before you respond or share anything."
    return "Few warning signs were found. That does not confirm the offer is genuine, so verify the recruiter and role anyway."
