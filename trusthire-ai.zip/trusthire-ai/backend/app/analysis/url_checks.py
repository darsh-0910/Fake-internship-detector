"""Static URL analysis. URLs are NEVER opened or fetched, so users are not exposed to the destination."""
import re
from typing import Dict, List
from urllib.parse import urlparse

SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rebrand.ly", "wa.me", "t.me"}
RISKY_TLDS = {"xyz", "top", "click", "work", "online", "site", "shop", "icu", "live", "buzz", "cfd", "sbs", "rest"}
SUSPICIOUS_WORDS = ("verify", "login", "secure", "payment", "pay", "offer", "selected", "register", "kyc")
FORM_HOSTS = {"docs.google.com", "forms.gle", "forms.office.com", "typeform.com", "airtable.com"}
TRUSTED_SUFFIXES = {"gov.in", "nic.in", "ac.in", "edu.in"}


def _registered_domain(host: str) -> str:
    parts = host.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in {"co.in", "ac.in", "gov.in", "nic.in", "org.in", "co.uk", "com.au"}:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def check_url(url: str, claimed_company: str = "") -> Dict:
    raw = url.strip()
    parsed = urlparse(raw if re.match(r"^https?://", raw, re.I) else "http://" + raw)
    host = (parsed.hostname or "").lower()
    flags: List[str] = []

    if not host:
        return {"url": raw, "domain": "", "flags": ["Could not read this link"], "note": "Invalid URL."}

    domain = _registered_domain(host)
    tld = host.rsplit(".", 1)[-1]

    if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", host):
        flags.append("Uses a raw IP address instead of a domain name")
    if host in SHORTENERS or domain in SHORTENERS:
        flags.append("Shortened or messaging link hides the real destination")
    if tld in RISKY_TLDS:
        flags.append(f"Uses a '.{tld}' domain that is commonly abused")
    if parsed.scheme == "http":
        flags.append("Not using HTTPS")
    if host.count(".") >= 4:
        flags.append("Has many subdomains, which can disguise the real site")
    if "xn--" in host:
        flags.append("Contains look-alike (punycode) characters")
    if "@" in parsed.netloc:
        flags.append("Contains '@' which can hide the real host")
    if any(w in host for w in SUSPICIOUS_WORDS):
        flags.append("Domain contains pressure/payment words such as 'verify' or 'pay'")
    if host in FORM_HOSTS or domain in FORM_HOSTS:
        flags.append("Generic form host: anyone can create these, so confirm the sender first")
    if claimed_company:
        slug = re.sub(r"[^a-z0-9]", "", claimed_company.lower())
        dslug = re.sub(r"[^a-z0-9]", "", domain)
        if slug and slug[:5] in dslug and domain != _registered_domain(host):
            pass
        elif slug and len(slug) >= 4 and slug[:5] not in dslug and not any(domain.endswith(s) for s in TRUSTED_SUFFIXES):
            flags.append(f"Domain does not appear related to '{claimed_company}'")
        elif slug and slug[:5] in dslug and domain.count("-") >= 2:
            flags.append("Looks like a look-alike of the company's name")

    if any(domain.endswith(s) for s in TRUSTED_SUFFIXES):
        note = "Government or academic domain. Still confirm the specific page and sender."
    elif flags:
        note = "Review the flags before opening. Do not enter personal or payment details."
    else:
        note = "No obvious structural red flags. This is not proof the link is safe; check the company's official site."

    return {"url": raw, "domain": domain, "flags": flags, "note": note}
