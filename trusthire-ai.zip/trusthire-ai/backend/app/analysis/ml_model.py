"""Baseline NLP classifier (TF-IDF + logistic regression).

The seed dataset below is a tiny, hand-written set of ILLUSTRATIVE examples so the demo runs.
For real use, replace it with a larger, carefully labelled, consent-based dataset (see README),
and evaluate precision, recall, F1 and false-positive rate on a held-out test set.
"""
import csv
import os
from typing import Optional

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "training_samples.csv")

_pipeline = None
_failed = False


def _load_rows():
    with open(DATA_PATH, newline="", encoding="utf-8") as f:
        return [(r["text"], int(r["label"])) for r in csv.DictReader(f)]


def _train():
    global _pipeline, _failed
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import make_pipeline

        rows = _load_rows()
        texts, labels = zip(*rows)
        _pipeline = make_pipeline(
            TfidfVectorizer(ngram_range=(1, 2), lowercase=True, min_df=1, sublinear_tf=True),
            LogisticRegression(max_iter=1000, class_weight="balanced"),
        )
        _pipeline.fit(texts, labels)
    except Exception:  # scikit-learn missing or data unreadable: rules still work
        _failed = True


def scam_probability(text: str) -> Optional[float]:
    """Return P(scam) in [0, 1], or None if the model is unavailable."""
    if _pipeline is None and not _failed:
        _train()
    if _pipeline is None:
        return None
    return float(_pipeline.predict_proba([text])[0][1])
