"""Lightweight entity extraction using regular expressions (no external services)."""
import re
from typing import Dict, List, Optional

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
URL_RE = re.compile(r"(?:https?://|www\.)[^\s<>\"')]+|\b(?:wa\.me|t\.me|bit\.ly|tinyurl\.com)/[^\s<>\"')]+", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+?91[\s-]?)?[6-9]\d{9}(?!\d)")
AMOUNT_RE = re.compile(r"(?:rs\.?|inr|₹|\u20b9)\s?\d[\d,]*(?:\.\d+)?(?:\s?(?:/-|k|lakh|lpa))?", re.I)
COMPANY_RE = re.compile(
    r"(?:at|from|with|by|of)\s+([A-Z][\w&.]*(?:\s+[A-Z][\w&.]*){0,3}\s+(?:Pvt\.?\s+Ltd\.?|Ltd\.?|Inc\.?|LLP|Technologies|Solutions|Systems|Labs|Corp(?:oration)?))"
)
ROLE_RE = re.compile(
    r"\b((?:[A-Z][a-z]+\s+){0,2}(?:Intern|Internship|Developer|Engineer|Analyst|Executive|Associate|Trainee|Designer|Manager))\b"
)


def _dedupe(items: List[str]) -> List[str]:
    seen, out = set(), []
    for i in items:
        k = i.strip().rstrip(".,;")
        if k and k.lower() not in seen:
            seen.add(k.lower())
            out.append(k)
    return out


def extract_entities(text: str) -> Dict:
    company: Optional[str] = None
    m = COMPANY_RE.search(text)
    if m:
        company = m.group(1).strip()
    role: Optional[str] = None
    r = ROLE_RE.search(text)
    if r:
        role = r.group(1).strip()
    return {
        "emails": _dedupe(EMAIL_RE.findall(text)),
        "urls": _dedupe(URL_RE.findall(text)),
        "phones": _dedupe(PHONE_RE.findall(text)),
        "amounts": _dedupe(AMOUNT_RE.findall(text)),
        "company": company,
        "role": role,
    }
