"""Rule-based scam indicators. Each rule returns a Signal-like dict.

Rules are deliberately explainable: every flag carries a plain-language reason.
No single rule proves a message is genuine or fraudulent.
"""
import re
from typing import Dict, List

FREE_EMAIL_DOMAINS = {
    "gmail.com", "yahoo.com", "yahoo.in", "outlook.com", "hotmail.com", "rediffmail.com",
    "proton.me", "protonmail.com", "icloud.com", "aol.com", "mail.com",
}

FEE_PATTERN = re.compile(
    r"(pay|deposit|send|transfer|submit)\b[^.\n]{0,40}"
    r"(registration|processing|security|training|kit|laptop|document|verification|refundable|confirmation|joining)?\s*"
    r"(fee|fees|charge|charges|amount|deposit)|"
    r"(registration|processing|security|training|joining|verification|document)\s*(fee|fees|charge|deposit)|"
    r"(rs\.?|inr|₹|\u20b9)\s?\d[\d,]*\s*(to|for)\s*(confirm|register|secure|book|reserve|process)",
    re.I,
)
URGENCY_PATTERN = re.compile(
    r"(within\s+\d+\s*(hours?|hrs?|minutes?)|today\s+only|last\s+(date|chance)|limited\s+(seats|slots)|"
    r"hurry|immediately|act\s+now|expires?\s+(today|tonight)|urgent(ly)?)",
    re.I,
)
SENSITIVE_PATTERN = re.compile(
    r"\b(otp|password|pin\b|cvv|aadhaar|aadhar|pan\s*card|bank\s*(account|details)|"
    r"passport|upi\s*(id|pin)|debit\s*card|credit\s*card)\b",
    re.I,
)
UNREALISTIC_PAY_PATTERN = re.compile(
    r"(earn|stipend|salary|income)[^.\n]{0,30}(rs\.?|inr|₹|\u20b9)\s?(\d{2,3}[,]?\d{3,})\s*(per\s*(day|week))|"
    r"(rs\.?|inr|₹|\u20b9)\s?(\d{4,6})\s*(per|/)\s*day|"
    r"(no\s+(interview|experience|skills?)\s+(required|needed)).{0,60}(earn|salary|stipend)|"
    r"(earn|make)\s+(up\s+to\s+)?(rs\.?|inr|₹|\u20b9)?\s?\d[\d,]*\s*(daily|per\s*day|a\s*day)",
    re.I,
)
NO_INTERVIEW_PATTERN = re.compile(
    r"(no\s+interview|without\s+(an\s+)?interview|direct(ly)?\s+selected|selected\s+without|"
    r"you\s+have\s+been\s+(selected|shortlisted)\s+(for|as)[^.\n]{0,60}(without|no))",
    re.I,
)
UNSOLICITED_PATTERN = re.compile(
    r"(we\s+(found|saw)\s+your\s+(resume|profile|cv)|your\s+(resume|profile)\s+(was\s+)?(shortlisted|selected)|"
    r"congratulations[,!]?\s+you\s+(have\s+been|are)\s+selected)",
    re.I,
)
MESSAGING_MOVE_PATTERN = re.compile(
    r"(contact|message|chat|text|join|reach)\s+(us\s+|me\s+|him\s+|her\s+)?(on|via|at)\s+(whatsapp|telegram|signal)|"
    r"t\.me/|wa\.me/|chat\.whatsapp\.com",
    re.I,
)
WORK_FROM_HOME_TASKS = re.compile(
    r"(like|subscribe|rate|review)\s+(youtube|videos?|products?|hotels?|google\s+maps)|"
    r"(data\s+entry|typing\s+job|form\s+filling|captcha)\b[^.\n]{0,60}(earn|pay|income)",
    re.I,
)
CRYPTO_PATTERN = re.compile(r"\b(crypto|bitcoin|usdt|forex|trading\s+account|investment\s+scheme)\b", re.I)
OFFICIAL_CAREERS_PATTERN = re.compile(r"(careers?|jobs?)\.[a-z0-9-]+\.[a-z.]+|/careers?(/|$)", re.I)


def _sig(id_: str, title: str, detail: str, severity: str, weight: int) -> Dict:
    return {"id": id_, "title": title, "detail": detail, "severity": severity, "weight": weight}


def run_rules(text: str, sender_email: str = "", claimed_company: str = "") -> List[Dict]:
    signals: List[Dict] = []

    if FEE_PATTERN.search(text):
        signals.append(_sig(
            "upfront_fee", "Asks for money upfront",
            "The message asks for a fee, deposit or payment. Genuine employers do not charge candidates for "
            "selection, registration, training or documents.", "high", 40))

    if SENSITIVE_PATTERN.search(text):
        signals.append(_sig(
            "sensitive_info", "Requests sensitive information",
            "It mentions OTPs, passwords, bank or ID details. Never share these with an unverified recruiter.",
            "high", 30))

    if UNREALISTIC_PAY_PATTERN.search(text):
        signals.append(_sig(
            "unrealistic_pay", "Compensation looks unrealistic",
            "The pay described is unusually high for the work or experience required.", "high", 25))

    if CRYPTO_PATTERN.search(text):
        signals.append(_sig(
            "investment_angle", "Mentions crypto, forex or investment schemes",
            "Job offers that involve investing or moving money are a common scam pattern.", "high", 25))

    if WORK_FROM_HOME_TASKS.search(text):
        signals.append(_sig(
            "task_scam", "Pay-per-task style work",
            "Tasks like liking videos or rating products for pay are a known task-scam pattern.", "high", 25))

    if URGENCY_PATTERN.search(text):
        signals.append(_sig(
            "urgency", "Pressure to act quickly",
            "Tight deadlines are used to stop you from checking the offer. Real recruiters allow time to verify.",
            "medium", 15))

    if NO_INTERVIEW_PATTERN.search(text):
        signals.append(_sig(
            "no_interview", "Selection without an interview",
            "Being selected with no interview or assessment is unusual for genuine hiring.", "medium", 15))

    if UNSOLICITED_PATTERN.search(text):
        signals.append(_sig(
            "unsolicited", "Unsolicited selection notice",
            "You may not have applied. Check whether you actually applied to this company.", "medium", 10))

    if MESSAGING_MOVE_PATTERN.search(text):
        signals.append(_sig(
            "off_platform", "Moves the conversation to WhatsApp/Telegram",
            "Recruiters can use these apps, but scams often move candidates there to avoid detection.",
            "low", 8))

    # Sender email checks
    emails = re.findall(r"[\w.+-]+@([\w-]+(?:\.[\w-]+)+)", (sender_email or "") + " " + text)
    domains = {d.lower() for d in emails}
    free = sorted(d for d in domains if d in FREE_EMAIL_DOMAINS)
    if free and claimed_company:
        signals.append(_sig(
            "free_email", "Free email address used",
            f"The recruiter uses a free email domain ({free[0]}) while claiming to represent {claimed_company}. "
            "Large companies normally email from their own domain.", "medium", 20))
    elif free:
        signals.append(_sig(
            "free_email", "Free email address used",
            f"The sender uses a free email domain ({free[0]}). Verify who they are through the company's website.",
            "low", 10))

    if claimed_company and domains:
        slug = re.sub(r"[^a-z0-9]", "", claimed_company.lower())
        corporate = [d for d in domains if d not in FREE_EMAIL_DOMAINS]
        if corporate and slug and not any(slug[:5] in re.sub(r"[^a-z0-9]", "", d) for d in corporate):
            signals.append(_sig(
                "domain_mismatch", "Email domain does not match the company",
                f"The email domain ({corporate[0]}) does not look related to '{claimed_company}'. "
                "A third-party recruiter is possible, so verify independently.", "medium", 20))

    return signals


def positive_signals(text: str) -> List[Dict]:
    """Weak reassurance signals. These only reduce the score slightly and never prove legitimacy."""
    out: List[Dict] = []
    if OFFICIAL_CAREERS_PATTERN.search(text):
        out.append(_sig(
            "careers_link", "Mentions a careers page",
            "The message points to a careers page. Open the company's site yourself and confirm the role is listed.",
            "positive", -8))
    return out
