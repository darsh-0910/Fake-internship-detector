from typing import Dict, Optional

from .extractor import extract_entities
from .ml_model import scam_probability
from .rules import positive_signals, run_rules
from .scoring import DISCLAIMER, combine, level_for, next_steps, summary_for
from .url_checks import check_url


def analyze_message(text: str, sender_email: Optional[str] = None, claimed_company: Optional[str] = None) -> Dict:
    text = (text or "").strip()
    entities = extract_entities(text)
    company = claimed_company or entities.get("company") or ""

    signals = run_rules(text, sender_email or "", company)
    signals += positive_signals(text)

    link_checks = [check_url(u, company) for u in entities["urls"][:5]]
    link_flag_count = sum(len(lc["flags"]) for lc in link_checks)
    for lc in link_checks:
        if lc["flags"]:
            signals.append({
                "id": "link_flags",
                "title": f"Suspicious link: {lc['domain'] or lc['url']}",
                "detail": "; ".join(lc["flags"]) + ".",
                "severity": "medium",
                "weight": 0,  # counted via link_flag_count to avoid double counting
            })

    ml_prob = scam_probability(text)
    score = combine(signals, link_flag_count, ml_prob)

    lv = level_for(score)
    order = {"high": 0, "medium": 1, "low": 2, "positive": 3}
    signals.sort(key=lambda s: order.get(s["severity"], 4))

    return {
        "score": score,
        "level": lv["level"],
        "label": lv["label"],
        "summary": summary_for(lv["level"], len([s for s in signals if s["severity"] != "positive"])),
        "signals": signals,
        "entities": entities,
        "link_checks": link_checks,
        "ml_probability": round(ml_prob, 3) if ml_prob is not None else None,
        "next_steps": next_steps(lv["level"], signals),
        "disclaimer": DISCLAIMER,
    }
