from typing import List, Optional
from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    message: str = Field(..., min_length=5, max_length=8000, description="Pasted message or email text")
    sender_email: Optional[str] = Field(None, description="Recruiter email, if known")
    claimed_company: Optional[str] = Field(None, description="Company the sender claims to represent")
    save_history: bool = Field(False, description="User consent to keep this analysis in history")


class Signal(BaseModel):
    id: str
    title: str
    detail: str
    severity: str  # "high" | "medium" | "low" | "positive"
    weight: int


class ExtractedEntities(BaseModel):
    emails: List[str] = []
    urls: List[str] = []
    phones: List[str] = []
    amounts: List[str] = []
    company: Optional[str] = None
    role: Optional[str] = None


class LinkCheck(BaseModel):
    url: str
    domain: str
    flags: List[str]
    note: str


class AnalyzeResponse(BaseModel):
    score: int
    level: str  # "lower" | "caution" | "high"
    label: str
    summary: str
    signals: List[Signal]
    entities: ExtractedEntities
    link_checks: List[LinkCheck]
    ml_probability: Optional[float] = None
    next_steps: List[str]
    disclaimer: str


class UrlCheckRequest(BaseModel):
    url: str = Field(..., min_length=3, max_length=2048)


class Opportunity(BaseModel):
    id: str
    title: str
    company: str
    location: str
    mode: str  # remote | onsite | hybrid
    type: str  # internship | job
    skills: List[str]
    stipend: Optional[str] = None
    source: str
    apply_url: str
    last_checked: str
    status: str  # "verified" | "source checked" | "not yet verified"
    match: Optional[int] = None
