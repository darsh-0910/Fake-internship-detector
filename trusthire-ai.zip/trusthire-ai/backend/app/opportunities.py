import json
import os
import re
from typing import List, Optional

from .schemas import Opportunity

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "opportunities.json")


def _load() -> List[dict]:
    with open(DATA_PATH, encoding="utf-8") as f:
        return json.load(f)


def _tokens(s: str) -> set:
    return {t for t in re.split(r"[^a-z0-9+#.]+", s.lower()) if t}


def search(
    q: Optional[str] = None,
    skills: Optional[str] = None,
    location: Optional[str] = None,
    mode: Optional[str] = None,
    type_: Optional[str] = None,
) -> List[Opportunity]:
    items = _load()
    wanted = _tokens(skills or "") | _tokens(q or "")
    results: List[Opportunity] = []
    for it in items:
        if mode and it["mode"] != mode:
            continue
        if type_ and it["type"] != type_:
            continue
        if location and location.lower() not in it["location"].lower() and it["mode"] != "remote":
            continue
        match = None
        if wanted:
            hay = _tokens(" ".join(it["skills"] + [it["title"], it["company"]]))
            overlap = len(wanted & hay)
            if overlap == 0:
                continue
            match = min(100, int(100 * overlap / max(len(wanted), 1)))
        results.append(Opportunity(**it, match=match))
    results.sort(key=lambda o: (o.match or 0), reverse=True)
    return results
