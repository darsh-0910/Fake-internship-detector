import os
from typing import List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

from . import opportunities
from .analysis.pipeline import analyze_message
from .analysis.url_checks import check_url
from .schemas import AnalyzeRequest, AnalyzeResponse, LinkCheck, Opportunity, UrlCheckRequest

load_dotenv()

app = FastAPI(
    title="TrustHire AI API",
    description="Detect the fake. Discover the real. Internship and job scam analysis.",
    version="0.1.0",
)

origins = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest):
    # Message text is analysed in memory and not stored. History saving is opt-in and
    # intentionally not implemented in this prototype (see README, "Privacy").
    return analyze_message(req.message, req.sender_email, req.claimed_company)


@app.post("/api/check-url", response_model=LinkCheck)
def check_link(req: UrlCheckRequest):
    # Static analysis only: the URL is never opened.
    return check_url(req.url)


@app.get("/api/opportunities", response_model=List[Opportunity])
def list_opportunities(
    q: Optional[str] = Query(None, description="Free-text role or keyword"),
    skills: Optional[str] = Query(None, description="Comma or space separated skills"),
    location: Optional[str] = None,
    mode: Optional[str] = Query(None, pattern="^(remote|onsite|hybrid)$"),
    type: Optional[str] = Query(None, pattern="^(internship|job)$"),
):
    return opportunities.search(q=q, skills=skills, location=location, mode=mode, type_=type)
