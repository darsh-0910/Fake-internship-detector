# TrustHire AI: Backend (FastAPI)

## Run
```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

## Endpoints
| Method | Path | Purpose |
|---|---|---|
| POST | `/api/analyze` | Analyse a pasted message. Returns score, level, reasons, entities, link checks, next steps |
| POST | `/api/check-url` | Static check of one URL (never opens it) |
| GET | `/api/opportunities` | Filter listings by `q`, `skills`, `location`, `mode`, `type` |
| GET | `/api/health` | Health check |

## How scoring works
1. **Rules** (`analysis/rules.py`): explainable flags such as upfront fees, OTP/ID requests, urgency, free email vs claimed company.
2. **Entity extraction** (`analysis/extractor.py`): emails, URLs, phones, amounts, company, role.
3. **URL checks** (`analysis/url_checks.py`): structural checks only (shorteners, raw IPs, risky TLDs, look-alikes). Links are never fetched.
4. **ML baseline** (`analysis/ml_model.py`): TF-IDF + logistic regression. It trains on a tiny illustrative seed file (`data/training_samples.csv`). Replace it with a real, consent-based dataset and report precision, recall, F1 and false-positive rate on a held-out test set.
5. **Blend** (`analysis/scoring.py`): 0-30 lower, 31-60 caution, 61-100 high. A high-severity rule hit sets a floor so the model cannot dilute it.

## Not implemented yet (by design of the prototype)
- Live DNS/WHOIS/reputation lookups and company careers-page comparison (add in `url_checks.py` where terms allow).
- Gmail API (needs explicit OAuth consent) and browser extension.
- Database. Opportunities come from `data/opportunities.json`, which holds **sample placeholders**. Replace with listings from approved APIs or official careers pages. Use the label "verified" only when your defined checks are complete.
- History and user reports. Do not store message text unless the user opts in, and publicly label a company only after human review.

## Test
```bash
pytest
```
