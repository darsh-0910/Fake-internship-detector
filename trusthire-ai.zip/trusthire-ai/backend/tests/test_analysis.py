from app.analysis.pipeline import analyze_message
from app.analysis.url_checks import check_url


def ids(result):
    return {s["id"] for s in result["signals"]}


def test_upfront_fee_is_high_risk():
    r = analyze_message("Congratulations! Pay Rs 999 registration fee to confirm your internship today.")
    assert "upfront_fee" in ids(r)
    assert r["level"] == "high"


def test_free_email_with_claimed_company():
    r = analyze_message("Hi, I am HR at Acme Technologies. Reply to acme.hr@gmail.com", claimed_company="Acme Technologies")
    assert "free_email" in ids(r)


def test_normal_message_not_high():
    r = analyze_message("Thank you for applying to the Data Analyst Intern role. We would like to schedule an interview next week.")
    assert r["level"] != "high"


def test_shortener_flagged():
    c = check_url("http://bit.ly/job-apply")
    assert any("Shortened" in f for f in c["flags"])


def test_disclaimer_always_present():
    r = analyze_message("Hello, please share your resume for the internship.")
    assert "not proof" in r["disclaimer"]
